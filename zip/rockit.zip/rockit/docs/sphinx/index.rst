.. rockit documentation master file, created by
   sphinx-quickstart on Wed Jul 24 12:29:07 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to rockit's documentation!
================================

 .. automodule:: rockit
    :members:

.. include:: gallery_dirs/index.rst

Coverage
========

* `Report <./coverage/index.html>`_

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
