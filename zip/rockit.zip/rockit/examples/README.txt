Gallery of rockit examples
==========================
