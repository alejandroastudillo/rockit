sudo docker build -t jgillis/meco_builder:rockit .
sudo docker push jgillis/meco_builder:rockit
