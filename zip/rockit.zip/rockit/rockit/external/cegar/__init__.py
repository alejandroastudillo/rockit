from .method import CegarMethod

method = CegarMethod