from .method import FatropMethod

method = FatropMethod