"""
Make a clone of rockit and enter it
$ git filter-repo --path grampc --subdirectory-filter rockit/external/grampc
"""
